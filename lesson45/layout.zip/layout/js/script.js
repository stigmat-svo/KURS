$(document).ready(function () {
  $(".button").click(function () {
    $(".side").slideToggle(1500);
    return false;
  });
});
